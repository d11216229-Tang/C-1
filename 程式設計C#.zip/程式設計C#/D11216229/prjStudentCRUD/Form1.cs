﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace prjStudentCRUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection cnn = new SqlConnection("Server=.; database=德明科大; uid=sa; pwd=takming");

        private void Form1_Load(object sender, EventArgs e)
        {
            ShowNew();
        }
        private void ShowNew()
        {
            cnn.Open();
            DataSet ds = new DataSet();
            string SQL = string.Format("select * from 德明科大");
            //SqlCommand cmd = new SqlCommand(SQL, cnn);
            SqlDataAdapter da = new SqlDataAdapter(SQL,cnn);

            
            dataGridView1.DataSource = ds.Tables["學生表"]; 
            cnn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            string SQL = string.Format("select * from 德明科大 where Sno='{0}'",txtSno.Text);
            SqlCommand cmd = new SqlCommand(SQL, cnn);

            cnn.Close();
        }

        
    }
}
