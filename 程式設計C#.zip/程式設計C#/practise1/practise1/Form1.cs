﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace practise1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection cnn = new SqlConnection("server=192.192.140.236; database=德明科大; uid=D123456; pwd=123456");
        private void Form1_Load(object sender, EventArgs e)
        {
            ShowNewData();
        }

        //資料表抓取.顯示
        private void ShowNewData()
        {
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            DataSet ds = new DataSet();
            string SQL = string.Format("select * from 學生表");
            SqlDataAdapter da = new SqlDataAdapter(SQL, cnn);
            da.Fill(ds, "學生表");
            dataGridView1.DataSource = ds.Tables["學生表"];
            cnn.Close();
        }

        //重設Textbox
        private void ResetStd()
        {
            txtSno.Clear();
            txtSna.Clear();
            rbM.Checked = true;
            txtSc.Clear();
        }

        //查詢
        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            string SQL = string.Format("select * from 學生表 where Sno='{0}'", txtSno.Text);
            SqlCommand cmd = new SqlCommand(SQL, cnn);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows == true)
            {
                dr.Read();
                txtSna.Text = dr[1].ToString();
                if (dr[2].ToString() == "True")
                    rbM.Checked = true;
                else
                    rbF.Checked = true;
                txtSc.Text = dr[3].ToString();
            }
            else
            {
                MessageBox.Show("查無該學生資料!!");
            }
            cnn.Close();
        }

        //新增
        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            string SQL = string.Format("insert into 學生表 values('{0}','{1}',{2},{3})", txtSno.Text, txtSna.Text, (rbM.Checked ? 1 : 0), txtSc.Text);
            SqlCommand cmd = new SqlCommand(SQL, cnn);
            if (cmd.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("新增學生資料成功!!");
                ResetStd();
                ShowNewData();
            }
            else
            {
                MessageBox.Show("新增學生資料失敗!!");
            }
            cnn.Close();
        }

        //修改
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            string SQL = string.Format("update 學生表 set Sna='{0}',Sex={1},Sc={2} where Sno='{3}'", txtSna.Text, (rbM.Checked ? 1 : 0), txtSc.Text, txtSno.Text);
            SqlCommand cmd = new SqlCommand(SQL, cnn);
            if (cmd.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("修改學生資料成功!!");
                ShowNewData();
            }
            else
            {
                MessageBox.Show("修改學生資料失敗!!");
            }
            cnn.Close();
        }

        //刪除
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            string SQL = string.Format("delete from 學生表 where Sno='{0}'", txtSno.Text);
            SqlCommand cmd = new SqlCommand(SQL, cnn);
            if (cmd.ExecuteNonQuery() > 0)
            {
                MessageBox.Show("刪除成功!!");
                ResetStd();
                ShowNewData();
            }
            else
            {
                MessageBox.Show("刪除失敗!!");
            }
            cnn.Close();
        }

        //結束
        private void btnEnd_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
