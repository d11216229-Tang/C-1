﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random rd = new Random();
            int[] a = new int[10];
            for(int i=0;i<a.Length; i++)
            {
                a[i] = rd.Next(1,100);
                for(int j = 0; j < i; j++)
                {
                    if (a[i] == a[j])
                    {
                        i--;
                        break;
                    }
                }
            }//取亂數
            foreach(int i in a)
            {
                Console.Write("{0} ", i);
            }
            int[] b = new int[10];
            for(int i = 0; i < a.Length; i++)
            {
                foreach(int x in a)
                {
                    if (x % 10 == i)
                    {
                        x = b[n];
                    }
                }
            }//個位數重新排列


            Console.ReadKey();
        }
    }
}
