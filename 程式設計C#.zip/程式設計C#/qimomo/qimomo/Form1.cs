﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace qimomo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection cnn = new SqlConnection("server=.;database=德明科大;uid=sa;pwd=takming");
        private void Form1_Load(object sender, EventArgs e)
        {
            ShowNewData();
        }
        private void ShowNewData()
        {
            DataSet ds = new DataSet();
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from 學生表", cnn);
            da.Fill(ds, "學生表");
            dataGridView1.DataSource = ds.Tables["學生表"];
            //2
            //dataGridView1.DataSource = ds;
            //dataGridView1.DataMember = "學生表";
            cnn.Close();
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            string SQL = string.Format("select * from 學生表 where Sno='{0}'",txtSno);
            // 命令執行的方法 ExecuteReader() --> Select 語法 ; ExecuteNonQuery() --> insert / update / delete
            SqlCommand cmd = new SqlCommand(SQL, cnn);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows == true)
            {
                dr.Read();
                txtSna.Text = dr[1].ToString();
                if (dr[2].ToString() == "True")
                    rbM.Checked = true;
                else
                    rbF.Checked = true;
                txtSc.Text = dr[3].ToString();
            }
            else
            {
                MessageBox.Show("沒有該學生資料!!");
            }
            cnn.Close();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            if (txtSno.Text == "")
            {
                MessageBox.Show("學號不能是空值!!");
                txtSno.Focus();
                return;
            }
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            string SQL = string.Format("insert into 學生表 values('{0}','{1}',{2},{3})", txtSno.Text, txtSna.Text, (rbM.Checked ? 1 : 0), txtSc.Text);
            // 命令執行的方法 ExecuteRReader() --> Select 語法 ; ExecuteNonQuery() --> insert / update / delete
            SqlCommand cmd = new SqlCommand(SQL, cnn);
            try
            {
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("新增學生資料成功!!");
                    ResetStdData();
                    ShowNewData();
                }
                else
                {
                    MessageBox.Show("新增學生資料失敗!!");
                }
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    MessageBox.Show("學號重複，新增失敗!!");
                    txtSno.Focus();
                }
                else if (ex.Number == 547)
                {
                    MessageBox.Show("成績未在0~100之間，新增失敗!!");
                    txtSc.Focus();
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
            }
            cnn.Close();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if(txtSno.Text==""|| txtSna.Text == ""|| txtSc.Text == "")
            {
                MessageBox.Show("有學生資料是空的，請在確認!!");
                return;
            }
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            string SQL = string.Format("update 學生表 set Sna = '{0}' , Sex = {1} , Sc = {2} where Sno = '{3}'", txtSna.Text, (rbM.Checked ? 1 : 0), txtSc.Text, txtSno.Text);
            // 命令執行的方法 ExecuteRReader() --> Select 語法 ; ExecuteNonQuery() --> insert / update / delete
            SqlCommand cmd = new SqlCommand(SQL, cnn);
            try
            {
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("修改學生資料成功!!");
                    ShowNewData();
                }
                else
                {
                    MessageBox.Show("修改學生資料失敗!!");
                }
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627)
                {
                    MessageBox.Show("學號重複，修改失敗!!");
                    txtSno.Focus();
                }
                else if (ex.Number == 547)
                {
                    MessageBox.Show("成績未在0~100之間，修改失敗!!");
                    txtSc.Focus();
                }
                else
                {
                    MessageBox.Show(ex.Message);
                }
            }
            cnn.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtSno.Text == "")
            {
                MessageBox.Show("刪除時，學號不能是空值!!");
                txtSno.Focus();
                return;
            }
            if (cnn.State == ConnectionState.Closed) cnn.Open();
            string SQL = string.Format("delete from 學生表 where Sno='{0}'", txtSno.Text);
            // 命令執行的方法 ExecuteRReader() --> Select 語法 ; ExecuteNonQuery() --> insert / update / delete
            SqlCommand cmd = new SqlCommand(SQL, cnn);
                if (cmd.ExecuteNonQuery() > 0)
                {
                    MessageBox.Show("刪除成功!!");
                    ResetStdData();
                    ShowNewData();
                }
                else
                {
                    MessageBox.Show("錯誤的學號，刪除失敗!!");
                }
            cnn.Close();
        }

        private void ResetStdData()
        {
            txtSno.Clear();
            txtSna.Clear();
            rbM.Checked = true;
            txtSc.Clear();
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
