﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjHwork03_1
{
    //表現優異 差強人意 有待加強
    interface IPass
    {
        int Score { get; set; }
        String Pass(int n);
    }
    interface ILevel
    {
        int H {  get; set; }
        int L {  get; set; }
        String Level(int n);
    }
    class Std : IPass, ILevel
    {
        private int _score = 60;
        public int Score
        {
            get { return _score; }
            set { _score = value; }
        }
        public String Pass(int n)
        {
            if (n >= _score)
                return "及格";
            else
                return "不及格";
        }
        private int _h = 80;
        public int H
        {
            get { return _h; }
            set { _h = value; }
        }
        private int _l = 55;
        public int L
        {
            get { return _l; }
            set { _l = value; }
        }
        public String Level(int n)
        {
            if (n >= _h)
                return "表現優異";
            else if (n >= _l)
                return "差強人意";
            else
                return "有待加強";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Std peter = new Std();
            Console.Write("請輸入學期成績：");
            int sc = int.Parse(Console.ReadLine());
            Console.WriteLine("分數：{0}", peter.Pass(sc));
            Console.WriteLine("評語：{0}", peter.Level(sc));
            Console.ReadKey();
        }
    }
}
