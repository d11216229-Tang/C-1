﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjHwork02_1
{
    class Student
    {
        public static int Num;
        public static void GetStudentNum()
        {
            Console.WriteLine("目前已建立{0}個學生!", Num);
        }
        public string Id { get; set; }
        public string Name { get; set; }
        private int _chi;
        public int Chi
        {
            get { return _chi; }
            set
            {
                if (value > 100)
                    _chi = 100;
                else if (value < 1)
                    _chi = 1;
                else
                    _chi = value;
            }
        }
        private int _eng;
        public int Eng
        {
            get { return _eng; }
            set
            {
                if (value > 100)
                    _eng = 100;
                else if (value < 1)
                    _eng = 1;
                else
                    _eng = value;
            }
        }
        private int _bcc;
        public int Bcc
        {
            get { return _bcc; }
            set
            {
                if (value > 100)
                    _bcc = 100;
                else if (value < 1)
                    _bcc = 1;
                else
                    _bcc = value;
            }
        }
        public double GetAvg()
        {
            double avg = (this.Chi+this.Eng+this.Bcc) / 3.0;
            return avg;
        }
        public Student()
        {
            Num += 1;
        }
        public void ShowData()
        {
            Console.WriteLine("學號:{0}\n姓名:{1}\n國文成績:{2}\n英文成績:{3}\n計概成績:{4}", this.Id, this.Name, this.Chi, this.Eng, this.Bcc);
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("有幾位學生:");
            int a = int.Parse(Console.ReadLine());
            Student[] stu = new Student[a];
            for(int i = 0; i < stu.Length; i++)
            {
                stu[i] = new Student();
                Console.Write("學號:");
                stu[i].Id = Console.ReadLine();
                Console.Write("姓名:");
                stu[i].Name = Console.ReadLine();
                Console.Write("國文成績:");
                stu[i].Chi = int.Parse(Console.ReadLine());
                Console.Write("英文成績:");
                stu[i].Eng = int.Parse(Console.ReadLine());
                Console.Write("計概成績:");
                stu[i].Bcc = int.Parse(Console.ReadLine());
                Student.GetStudentNum();
            }
            Console.Write("\n輸入姓名查詢學生資料:");
            string x = Console.ReadLine();
            int j;
            for(j = 0; j < a; j++)
            {
                if (x == stu[j].Name)
                    break;
            }
            if (j == a)
                Console.WriteLine("找不到該位同學。");
            else
                stu[j].ShowData();

            Console.ReadKey();
        }
    }
}
