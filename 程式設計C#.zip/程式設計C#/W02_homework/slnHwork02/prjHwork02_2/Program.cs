﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjHwork02_2
{
    class Shape
    {
        public static int shape;
        public static double _area;
        
        public virtual void ShowData()
        {
            Console.WriteLine("目前累積 {0} 個型狀，面積總和 {1}", shape, _area);
        }
    }
    class Circle:Shape
    {
        public int Radius {  get; set; }    //圓半徑
        public double Area { get; set; }    //圓面積
        public Circle()
        {
            shape += 1;
        }
        public override void ShowData()
        {
            Console.WriteLine("建立一個圓形，半徑 {0} ，面積 {1}", this.Radius, this.Area);
            _area += this.Area;
            base.ShowData();
        }
    }
    class Rectangle:Shape
    {
        public int Length {  get; set; }    //矩形長
        public int Width { get; set; }      //矩形寬
        public int Area { get; set; }       //矩形面積
        public Rectangle()
        {
            shape += 1;
        }
        public override void ShowData()
        {
            Console.WriteLine("建立一個矩形，長 {0} 寬 {1} ，面積 {2}", this.Length, this.Width, this.Area);
            _area += this.Area;
            base.ShowData();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("請選擇建立的形狀 --> 1.圓形 2.矩形 其他.結束：");
            string a = Console.ReadLine();
            Shape S;
            while (a == "1" || a == "2")
            {
                if (a == "1")
                {
                    Circle C = new Circle();
                    S = C;
                    Console.Write("圓半徑=");
                    ((Circle)S).Radius = int.Parse(Console.ReadLine());
                    ((Circle)S).Area = ((Circle)S).Radius * ((Circle)S).Radius * 3.14;
                }
                else if (a == "2")
                {
                    Rectangle R = new Rectangle();
                    S = R;
                    Console.Write("矩形長=");
                    ((Rectangle)S).Length = int.Parse(Console.ReadLine());
                    Console.Write("矩形寬=");
                    ((Rectangle)S).Width = int.Parse(Console.ReadLine());
                    ((Rectangle)S).Area = ((Rectangle)S).Length * ((Rectangle)S).Width;
                }
                else
                    return;
                S.ShowData();
                Console.WriteLine("========================================");
                Console.Write("請選擇建立的形狀 --> 1.圓形 2.矩形 其他.結束：");
                a = Console.ReadLine();
            }
            Console.ReadKey();
        }
    }
}
